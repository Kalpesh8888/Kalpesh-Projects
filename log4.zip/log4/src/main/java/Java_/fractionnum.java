package Java_;

public class fractionnum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int num=6;
int frac=1;
for(int i=1;i<=num;i++) {
	frac=frac*i;
	
}
System.out.println(frac);
	}

}
