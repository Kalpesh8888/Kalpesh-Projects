package JavaProgram;

import java.util.Arrays;
import java.util.Collections;

public class jcchjkccc {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String s="my name is rajkumar";
		String[] x = s.split(" ");
		
		
		for(int i=x.length-1;i>=0;i--){
			System.out.println(x[i]);
			                          }
		

	}

}
