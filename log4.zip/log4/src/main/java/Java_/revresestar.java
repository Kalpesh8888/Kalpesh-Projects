package Java_;

public class revresestar {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for(int j=4;j>0;j--) {
			
			for(int k=1;k<=j;k++) {
				System.out.print("*");
			}
			System.out.println();
		}
		//System.out.println();
		for(int i=1;i<=4;i++) {
			for(int j=0;j<i;j++) {
				System.out.print("*");
			}
			System.out.println();
			
		}

	}
	

}
