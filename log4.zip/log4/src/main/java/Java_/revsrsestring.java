package Java_;

public class revsrsestring {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String s="rajkumar";
		int i=s.length()-1;
		while(true) {
			
			System.out.println(s.charAt(i));
			i--;
			
		}

	}

}
