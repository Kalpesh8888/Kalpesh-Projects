package JavaProgram;

public class Reveresearray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int a[]= {10,40,48,78,48,15};
		
		for (int i=a.length-1;i>=0;i--) {
			System.out.println(a[i]);
		}
		

	}

}
