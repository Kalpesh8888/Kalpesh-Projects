package JavaProgram;

public class Fabonasinum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num=10;
		int fabonum=0;
		for (int i=1;i<=10;i++) {
			
			fabonum=fabonum+i;
			
			System.out.println(fabonum
					);
			
		}
		
		
		
		
		
		
		
		
		
		
		
		
		

	}

}
