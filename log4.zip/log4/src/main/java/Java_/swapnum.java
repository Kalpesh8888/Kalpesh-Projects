package Java_;

public class swapnum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      int a=10,b=18,temp=0;
      
     // temp=a;
     // a=b;
      //b=temp;
      //System.out.println(a+" "+b);
    //  a=a+b;
   //   b=a-b;
   //   a=a-b;
      System.out.println(a+" "+b);
      a=a*b;
      a=a/10;
      
      
      System.out.println(a+" "+b);
      
     
	}

}
