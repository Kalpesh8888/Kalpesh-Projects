package ListenerP;

import org.testng.ITestListener;
import org.testng.TestListenerAdapter;

public class Listener extends TestListenerAdapter {
	
	public void onTestStart() {
		
	}
	

}
